var structlib_c_z_i_1_1_general_document_info =
[
    [ "GeneralDocumentInfo", "structlib_c_z_i_1_1_general_document_info.html#a84d09d72d5787e904d356c022cb18b9f", null ],
    [ "comment", "structlib_c_z_i_1_1_general_document_info.html#a633f48b2bd3356c426a0716ffbae45ae", null ],
    [ "creationDateTime", "structlib_c_z_i_1_1_general_document_info.html#a831ea6520302e16ab56615c3aee316ec", null ],
    [ "description", "structlib_c_z_i_1_1_general_document_info.html#ad6c87c00c5039477b2887a2bd8099469", null ],
    [ "keywords", "structlib_c_z_i_1_1_general_document_info.html#adee12c915203b5bd17d150f362320e83", null ],
    [ "name", "structlib_c_z_i_1_1_general_document_info.html#afc37e71ba6b59171c877c17749b91aa3", null ],
    [ "rating", "structlib_c_z_i_1_1_general_document_info.html#a26ded0bae7ffb1bc68fef7f1862c0508", null ],
    [ "title", "structlib_c_z_i_1_1_general_document_info.html#ab35797e1b6c3a8e5c8476b43672180bc", null ],
    [ "userName", "structlib_c_z_i_1_1_general_document_info.html#a2ac0606c9395217d63c586f9bd356f3e", null ]
];
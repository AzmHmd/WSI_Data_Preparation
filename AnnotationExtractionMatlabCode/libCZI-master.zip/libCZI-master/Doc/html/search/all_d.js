var searchData=
[
  ['maxdim',['MaxDim',['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424a217b2ee2e671fc8ef713c2c309d0fd13',1,'libCZI']]],
  ['maxmindex',['maxMindex',['../structlib_c_z_i_1_1_sub_block_statistics.html#ad49c1710047fea5751e8b27263b0c62d',1,'libCZI::SubBlockStatistics']]],
  ['memblktype',['MemBlkType',['../classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108',1,'libCZI::ISubBlock::MemBlkType()'],['../classlib_c_z_i_1_1_i_metadata_segment.html#a3acd5e2bf5161629f1ee56ecef9b3b72',1,'libCZI::IMetadataSegment::MemBlkType()']]],
  ['metadata',['Metadata',['../classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108ada66dacad65a36fd265a7a2dacae197c',1,'libCZI::ISubBlock']]],
  ['mindex',['mIndex',['../structlib_c_z_i_1_1_sub_block_info.html#a413dbeb605db073feaf280256ddc9715',1,'libCZI::SubBlockInfo']]],
  ['mindim',['MinDim',['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424a4664bf19d8f3ef0300bc3d7170ea139f',1,'libCZI']]],
  ['minificationfactor',['minificationFactor',['../structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#a397023f140015ffb12dc87bdfd721dc1',1,'libCZI::PyramidStatistics::PyramidLayerInfo::minificationFactor()'],['../structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_pyramid_layer_info.html#a533419024a6645305568efbd42100b45',1,'libCZI::ISingleChannelPyramidLayerTileAccessor::PyramidLayerInfo::minificationFactor()']]],
  ['minmindex',['minMindex',['../structlib_c_z_i_1_1_sub_block_statistics.html#a3123641e5b748a84744082a651f199a9',1,'libCZI::SubBlockStatistics']]],
  ['missingdimension',['MissingDimension',['../structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60a06a04b63fba5058c3dc36269ef6dfaaa',1,'libCZI::LibCZIInvalidPlaneCoordinateException']]],
  ['mode',['mode',['../structlib_c_z_i_1_1_sub_block_info.html#a0e293a3e7ea6188e3df08ae74c16221f',1,'libCZI::SubBlockInfo']]],
  ['multi_2dchannel_2dcomposition',['Multi-channel-composition',['../multichannelcomposition.html',1,'']]]
];

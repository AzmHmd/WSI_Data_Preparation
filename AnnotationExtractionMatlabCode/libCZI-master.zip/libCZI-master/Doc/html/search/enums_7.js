var searchData=
[
  ['pixeltype',['PixelType',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834',1,'libCZI']]]
];

var searchData=
[
  ['attachmentinfo',['AttachmentInfo',['../structlib_c_z_i_1_1_attachment_info.html',1,'libCZI']]]
];

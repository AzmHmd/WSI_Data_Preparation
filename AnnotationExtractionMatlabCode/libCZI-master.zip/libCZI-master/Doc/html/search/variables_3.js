var searchData=
[
  ['d',['d',['../structlib_c_z_i_1_1_i_display_settings_1_1_cubic_spline_coefficients.html#a0d9722f64cd3f752dee9074decabd4ab',1,'libCZI::IDisplaySettings::CubicSplineCoefficients']]],
  ['description',['description',['../structlib_c_z_i_1_1_general_document_info.html#ad6c87c00c5039477b2887a2bd8099469',1,'libCZI::GeneralDocumentInfo']]],
  ['dimbounds',['dimBounds',['../structlib_c_z_i_1_1_sub_block_statistics.html#a10b6e7fb9312e93b1e9785daed56e44e',1,'libCZI::SubBlockStatistics']]],
  ['dimension',['dimension',['../structlib_c_z_i_1_1_dimension_and_value.html#a0274b97af7cdb3f56231868fb22e92b1',1,'libCZI::DimensionAndValue::dimension()'],['../structlib_c_z_i_1_1_dimension_and_start_size.html#a2f34bc92aad06f8c6d4d54e847e5a9f9',1,'libCZI::DimensionAndStartSize::dimension()']]],
  ['drawtileborder',['drawTileBorder',['../structlib_c_z_i_1_1_i_single_channel_tile_accessor_1_1_options.html#aa1d7947be1a24339a446efbeb371d34d',1,'libCZI::ISingleChannelTileAccessor::Options::drawTileBorder()'],['../structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_options.html#a53cf2b7a087395332e1daae3a3318b08',1,'libCZI::ISingleChannelPyramidLayerTileAccessor::Options::drawTileBorder()'],['../structlib_c_z_i_1_1_i_single_channel_scaling_tile_accessor_1_1_options.html#ad0ff6bfe4369dd315edc4cfca9747596',1,'libCZI::ISingleChannelScalingTileAccessor::Options::drawTileBorder()'],['../structlib_c_z_i_1_1_compositors_1_1_compose_single_tile_options.html#a9d4799bf8b8a0a89c50506f3a0af4cb2',1,'libCZI::Compositors::ComposeSingleTileOptions::drawTileBorder()']]]
];

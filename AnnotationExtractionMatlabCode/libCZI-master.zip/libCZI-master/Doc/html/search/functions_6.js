var searchData=
[
  ['nearestneighborresize',['NearestNeighborResize',['../classlib_c_z_i_1_1_utils.html#af19f5d15750c0949f3dd4ebb5684c7d3',1,'libCZI::Utils::NearestNeighborResize(libCZI::IBitmapData *bmSrc, int dstWidth, int dstHeight)'],['../classlib_c_z_i_1_1_utils.html#a6d56f447db1707083cb47042729bfabf',1,'libCZI::Utils::NearestNeighborResize(libCZI::IBitmapData *bmSrc, int dstWidth, int dstHeight, const DblRect &amp;roiSrc, const DblRect &amp;roiDest)']]]
];

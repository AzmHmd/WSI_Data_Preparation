var searchData=
[
  ['username',['userName',['../structlib_c_z_i_1_1_general_document_info.html#a2ac0606c9395217d63c586f9bd356f3e',1,'libCZI::GeneralDocumentInfo']]]
];

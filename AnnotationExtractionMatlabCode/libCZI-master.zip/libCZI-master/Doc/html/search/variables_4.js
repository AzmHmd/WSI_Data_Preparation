var searchData=
[
  ['enabletinting',['enableTinting',['../structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a55842ad5f759439b4e7909b19a3e10ad',1,'libCZI::Compositors::ChannelInfo']]]
];

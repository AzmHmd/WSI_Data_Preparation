var searchData=
[
  ['maxdim',['MaxDim',['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424a217b2ee2e671fc8ef713c2c309d0fd13',1,'libCZI']]],
  ['metadata',['Metadata',['../classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108ada66dacad65a36fd265a7a2dacae197c',1,'libCZI::ISubBlock']]],
  ['mindim',['MinDim',['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424a4664bf19d8f3ef0300bc3d7170ea139f',1,'libCZI']]],
  ['missingdimension',['MissingDimension',['../structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60a06a04b63fba5058c3dc36269ef6dfaaa',1,'libCZI::LibCZIInvalidPlaneCoordinateException']]]
];

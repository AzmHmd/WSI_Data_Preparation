var searchData=
[
  ['scopedbitmaplocker',['ScopedBitmapLocker',['../classlib_c_z_i_1_1_scoped_bitmap_locker.html#a871926718a1b6f2b00002d327154049b',1,'libCZI::ScopedBitmapLocker::ScopedBitmapLocker(tBitmap bmData)'],['../classlib_c_z_i_1_1_scoped_bitmap_locker.html#a3d5e197884453daaa5c6252a6dd19e9e',1,'libCZI::ScopedBitmapLocker::ScopedBitmapLocker(const ScopedBitmapLocker&lt; tBitmap &gt; &amp;other)'],['../classlib_c_z_i_1_1_scoped_bitmap_locker.html#ae8096865753018bffff4544c28ab4945',1,'libCZI::ScopedBitmapLocker::ScopedBitmapLocker(ScopedBitmapLocker&lt; tBitmap &gt; &amp;&amp;other) noexcept']]],
  ['set',['Set',['../classlib_c_z_i_1_1_c_dim_coordinate.html#a9f6d967df6c2040e395c0710e8374909',1,'libCZI::CDimCoordinate::Set()'],['../classlib_c_z_i_1_1_c_dim_bounds.html#a7a872729a919b4573755032fbfdfc183',1,'libCZI::CDimBounds::Set()']]],
  ['setsiteobject',['SetSiteObject',['../namespacelib_c_z_i.html#a19b47bdfc502b06cbee0166ac5da6a3e',1,'libCZI']]]
];

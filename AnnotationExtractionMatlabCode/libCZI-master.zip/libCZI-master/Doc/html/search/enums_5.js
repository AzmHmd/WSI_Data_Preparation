var searchData=
[
  ['imagedecodertype',['ImageDecoderType',['../namespacelib_c_z_i.html#a68cd7521fd89880f820ea55baf6f6179',1,'libCZI']]]
];

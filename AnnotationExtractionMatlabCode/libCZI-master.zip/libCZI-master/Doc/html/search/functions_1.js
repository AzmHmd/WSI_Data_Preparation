var searchData=
[
  ['dangerousgetrawdata',['DangerousGetRawData',['../classlib_c_z_i_1_1_i_sub_block.html#a6f84a58437af59bac64a6147369ddae4',1,'libCZI::ISubBlock::DangerousGetRawData(MemBlkType type, const void *&amp;ptr, size_t &amp;size) const =0'],['../classlib_c_z_i_1_1_i_sub_block.html#acd9396cc5d366de99b37a26c98031d66',1,'libCZI::ISubBlock::DangerousGetRawData(MemBlkType type, const Q *&amp;ptr, size_t &amp;size) const'],['../classlib_c_z_i_1_1_i_attachment.html#ab809465974cfe7eaf10e171cc1c7bc15',1,'libCZI::IAttachment::DangerousGetRawData(const void *&amp;ptr, size_t &amp;size) const =0'],['../classlib_c_z_i_1_1_i_attachment.html#a2f716dad937d9bc600c27ff33c94dd4e',1,'libCZI::IAttachment::DangerousGetRawData(const Q *&amp;ptr, size_t &amp;size) const'],['../classlib_c_z_i_1_1_i_metadata_segment.html#a749349eab738a5fd7e5bce2e67440953',1,'libCZI::IMetadataSegment::DangerousGetRawData()']]],
  ['decode',['Decode',['../classlib_c_z_i_1_1_i_decoder.html#a14733581cd1ba72bd39a156b98b52835',1,'libCZI::IDecoder']]],
  ['dimcoordinatetostring',['DimCoordinateToString',['../classlib_c_z_i_1_1_utils.html#aeb42843e65615302b51b68ad2b376e6d',1,'libCZI::Utils']]],
  ['dimensiontochar',['DimensionToChar',['../classlib_c_z_i_1_1_utils.html#ae97a98f63029f18282b1c940a79518a4',1,'libCZI::Utils']]]
];

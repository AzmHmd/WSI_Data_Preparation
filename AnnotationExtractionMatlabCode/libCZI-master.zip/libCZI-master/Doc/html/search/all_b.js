var searchData=
[
  ['keywords',['keywords',['../structlib_c_z_i_1_1_general_document_info.html#adee12c915203b5bd17d150f362320e83',1,'libCZI::GeneralDocumentInfo']]]
];

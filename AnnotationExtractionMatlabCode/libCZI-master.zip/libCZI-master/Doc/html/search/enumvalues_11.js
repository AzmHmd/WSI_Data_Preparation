var searchData=
[
  ['withjxrdecoder',['WithJxrDecoder',['../namespacelib_c_z_i.html#a77743727a5f0709a64237e58b9254983a6cdacd623c3a47d457783e5410437a42',1,'libCZI']]]
];

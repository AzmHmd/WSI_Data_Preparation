var searchData=
[
  ['name',['name',['../structlib_c_z_i_1_1_attachment_info.html#a0e68d0e359ff6dc8ae54e39267486a43',1,'libCZI::AttachmentInfo::name()'],['../structlib_c_z_i_1_1_general_document_info.html#afc37e71ba6b59171c877c17749b91aa3',1,'libCZI::GeneralDocumentInfo::name()']]],
  ['nearestneighborresize',['NearestNeighborResize',['../classlib_c_z_i_1_1_utils.html#af19f5d15750c0949f3dd4ebb5684c7d3',1,'libCZI::Utils::NearestNeighborResize(libCZI::IBitmapData *bmSrc, int dstWidth, int dstHeight)'],['../classlib_c_z_i_1_1_utils.html#a6d56f447db1707083cb47042729bfabf',1,'libCZI::Utils::NearestNeighborResize(libCZI::IBitmapData *bmSrc, int dstWidth, int dstHeight, const DblRect &amp;roiSrc, const DblRect &amp;roiDest)']]],
  ['notenoughdata',['NotEnoughData',['../structlib_c_z_i_1_1_lib_c_z_i_c_z_i_parse_exception.html#a32a6c8ab31a657e490e5c605c97efb40ab6e495eeaee7cdf1bac313472e4681ac',1,'libCZI::LibCZICZIParseException']]]
];

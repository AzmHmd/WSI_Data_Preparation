var searchData=
[
  ['gradationcurvemode',['GradationCurveMode',['../classlib_c_z_i_1_1_i_display_settings.html#a8e600e80a4999495c1ab1f637ffb94ff',1,'libCZI::IDisplaySettings']]]
];

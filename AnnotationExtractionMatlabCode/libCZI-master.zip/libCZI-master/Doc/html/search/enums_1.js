var searchData=
[
  ['compressionmode',['CompressionMode',['../namespacelib_c_z_i.html#a672959aa909ce27c5a549465200b08fb',1,'libCZI']]]
];

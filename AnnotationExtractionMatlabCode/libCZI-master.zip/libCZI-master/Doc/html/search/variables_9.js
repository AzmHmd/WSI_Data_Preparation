var searchData=
[
  ['maxmindex',['maxMindex',['../structlib_c_z_i_1_1_sub_block_statistics.html#ad49c1710047fea5751e8b27263b0c62d',1,'libCZI::SubBlockStatistics']]],
  ['mindex',['mIndex',['../structlib_c_z_i_1_1_sub_block_info.html#a413dbeb605db073feaf280256ddc9715',1,'libCZI::SubBlockInfo']]],
  ['minificationfactor',['minificationFactor',['../structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#a397023f140015ffb12dc87bdfd721dc1',1,'libCZI::PyramidStatistics::PyramidLayerInfo::minificationFactor()'],['../structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_pyramid_layer_info.html#a533419024a6645305568efbd42100b45',1,'libCZI::ISingleChannelPyramidLayerTileAccessor::PyramidLayerInfo::minificationFactor()']]],
  ['minmindex',['minMindex',['../structlib_c_z_i_1_1_sub_block_statistics.html#a3123641e5b748a84744082a651f199a9',1,'libCZI::SubBlockStatistics']]],
  ['mode',['mode',['../structlib_c_z_i_1_1_sub_block_info.html#a0e293a3e7ea6188e3df08ae74c16221f',1,'libCZI::SubBlockInfo']]]
];

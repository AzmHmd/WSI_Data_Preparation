var searchData=
[
  ['generaldocumentinfo',['GeneralDocumentInfo',['../structlib_c_z_i_1_1_general_document_info.html',1,'libCZI']]]
];

var searchData=
[
  ['scopedbitmaplockerp',['ScopedBitmapLockerP',['../namespacelib_c_z_i.html#aa0a4df11f476d960267cc3757d7e889d',1,'libCZI']]],
  ['scopedbitmaplockersp',['ScopedBitmapLockerSP',['../namespacelib_c_z_i.html#a44eca12300534095278df46d8b7ef824',1,'libCZI']]]
];

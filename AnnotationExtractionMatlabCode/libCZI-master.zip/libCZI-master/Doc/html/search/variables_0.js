var searchData=
[
  ['a',['a',['../structlib_c_z_i_1_1_i_display_settings_1_1_cubic_spline_coefficients.html#a543026ecf7bb3dcfa86d89687d90e6ac',1,'libCZI::IDisplaySettings::CubicSplineCoefficients']]]
];

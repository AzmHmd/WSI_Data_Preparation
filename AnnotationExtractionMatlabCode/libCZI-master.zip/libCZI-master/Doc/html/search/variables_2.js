var searchData=
[
  ['c',['c',['../structlib_c_z_i_1_1_i_display_settings_1_1_cubic_spline_coefficients.html#a46455db9e87f331f748d04a8be4308d4',1,'libCZI::IDisplaySettings::CubicSplineCoefficients']]],
  ['coefficients',['coefficients',['../structlib_c_z_i_1_1_i_display_settings_1_1_spline_data.html#a2daa2f1b10f4bf574f13e4fd699c5b33',1,'libCZI::IDisplaySettings::SplineData']]],
  ['color',['color',['../structlib_c_z_i_1_1_compositors_1_1_tinting_color.html#ac703e2b5d55edd041a3fc4974709a3ce',1,'libCZI::Compositors::TintingColor']]],
  ['comment',['comment',['../structlib_c_z_i_1_1_general_document_info.html#a633f48b2bd3356c426a0716ffbae45ae',1,'libCZI::GeneralDocumentInfo']]],
  ['contentfiletype',['contentFileType',['../structlib_c_z_i_1_1_attachment_info.html#a0cd022f5e1f564d410165faeb72eadbb',1,'libCZI::AttachmentInfo']]],
  ['contentguid',['contentGuid',['../structlib_c_z_i_1_1_attachment_info.html#a7be40455831774e65cd394592af97220',1,'libCZI::AttachmentInfo']]],
  ['coordinate',['coordinate',['../structlib_c_z_i_1_1_sub_block_info.html#ae4acf2922fe594327d1c6fbfb2062781',1,'libCZI::SubBlockInfo']]],
  ['count',['count',['../structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_statistics.html#a9622c14764217c603d3e50565c768702',1,'libCZI::PyramidStatistics::PyramidLayerStatistics']]],
  ['creationdatetime',['creationDateTime',['../structlib_c_z_i_1_1_general_document_info.html#a831ea6520302e16ab56615c3aee316ec',1,'libCZI::GeneralDocumentInfo']]]
];

var searchData=
[
  ['tintingcolor',['TintingColor',['../structlib_c_z_i_1_1_compositors_1_1_tinting_color.html',1,'libCZI::Compositors']]]
];

var indexSectionsWithContent =
{
  0: "3abcdefghijklmnoprstuvwxyz",
  1: "abcdgiloprstu",
  2: "l",
  3: "cdegilnoprstu",
  4: "abcdeghklmnprstuvwxy",
  5: "s",
  6: "acdegimps",
  7: "abcdfghijlmnrstuvwxz",
  8: "3abcilmtu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};


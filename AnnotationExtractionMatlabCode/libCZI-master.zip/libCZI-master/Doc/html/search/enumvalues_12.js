var searchData=
[
  ['xmlmetadata',['XmlMetadata',['../classlib_c_z_i_1_1_i_metadata_segment.html#a3acd5e2bf5161629f1ee56ecef9b3b72a33f06811a574191b45596337520b8984',1,'libCZI::IMetadataSegment']]]
];

var searchData=
[
  ['linear',['Linear',['../classlib_c_z_i_1_1_i_display_settings.html#a8e600e80a4999495c1ab1f637ffb94ffa32a843da6ea40ab3b17a3421ccdf671b',1,'libCZI::IDisplaySettings']]]
];

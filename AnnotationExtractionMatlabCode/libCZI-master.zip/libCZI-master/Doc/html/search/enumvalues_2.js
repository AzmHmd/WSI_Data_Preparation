var searchData=
[
  ['c',['C',['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424a0d61f8370cad1d412f80b84d143e1257',1,'libCZI']]],
  ['coordinateoutofrange',['CoordinateOutOfRange',['../structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60a4a35479ed0f04e5d5ea428427869570b',1,'libCZI::LibCZIInvalidPlaneCoordinateException']]],
  ['corrupteddata',['CorruptedData',['../structlib_c_z_i_1_1_lib_c_z_i_c_z_i_parse_exception.html#a32a6c8ab31a657e490e5c605c97efb40a14ce06721aa54faf8e86a779a37ada3f',1,'libCZI::LibCZICZIParseException']]],
  ['couldntdeterminepixeltype',['CouldntDeterminePixelType',['../classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#afac26a03ad8be1d8314911a58b9b08b5ab9a3da346ec292af4ab30323d51475a7',1,'libCZI::LibCZIAccessorException']]]
];

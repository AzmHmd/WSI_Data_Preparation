var searchData=
[
  ['tinting',['tinting',['../structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a5bc342e6d105188d423110cbbd48af87',1,'libCZI::Compositors::ChannelInfo']]],
  ['title',['title',['../structlib_c_z_i_1_1_general_document_info.html#ab35797e1b6c3a8e5c8476b43672180bc',1,'libCZI::GeneralDocumentInfo']]]
];

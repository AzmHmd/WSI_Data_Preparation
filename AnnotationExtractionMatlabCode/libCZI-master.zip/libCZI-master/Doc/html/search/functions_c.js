var searchData=
[
  ['unlock',['Unlock',['../classlib_c_z_i_1_1_i_bitmap_data.html#a473c706c604fd687fb653bd06f0e0356',1,'libCZI::IBitmapData']]]
];

var searchData=
[
  ['indexsetfromstring',['IndexSetFromString',['../classlib_c_z_i_1_1_utils.html#a69fdbdc41c4700f35a648a516757bbca',1,'libCZI::Utils']]],
  ['intersect',['Intersect',['../structlib_c_z_i_1_1_int_rect.html#a705db72d07819bb7dc89de8e85a695e1',1,'libCZI::IntRect::Intersect(const IntRect &amp;r) const'],['../structlib_c_z_i_1_1_int_rect.html#ab90921fdce94ba493985e125fdb32d39',1,'libCZI::IntRect::Intersect(const IntRect &amp;a, const IntRect &amp;b)']]],
  ['intersectswith',['IntersectsWith',['../structlib_c_z_i_1_1_int_rect.html#a7f1f1d29e2b43f840dd81584ae15bb15',1,'libCZI::IntRect']]],
  ['invalidate',['Invalidate',['../structlib_c_z_i_1_1_sub_block_statistics.html#a3b328670c14542bec4e37763379ca319',1,'libCZI::SubBlockStatistics::Invalidate()'],['../structlib_c_z_i_1_1_int_rect.html#ae9c4747389326efa22ba0ab98a15359b',1,'libCZI::IntRect::Invalidate()'],['../structlib_c_z_i_1_1_dbl_rect.html#a3eb28e789f023aa43531d7917d6ba54d',1,'libCZI::DblRect::Invalidate()']]],
  ['iscontained',['IsContained',['../classlib_c_z_i_1_1_i_index_set.html#aca780c448b752cff46fcabb8f25e3c9a',1,'libCZI::IIndexSet']]],
  ['isenabled',['IsEnabled',['../classlib_c_z_i_1_1_i_site.html#a56c0d12cfa78ecb83fb5bbd0f500ee30',1,'libCZI::ISite']]],
  ['islayer0',['IsLayer0',['../structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#a9cafde3541c9752058dcbeaaa73d4686',1,'libCZI::PyramidStatistics::PyramidLayerInfo']]],
  ['ismindexvalid',['IsMIndexValid',['../structlib_c_z_i_1_1_sub_block_statistics.html#a61f70e5acf237b4d4550f18dbc23b4a7',1,'libCZI::SubBlockStatistics']]],
  ['isnotidentifiedaspyramidlayer',['IsNotIdentifiedAsPyramidLayer',['../structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#afc9992be68effd61fa8ff828c3fe467d',1,'libCZI::PyramidStatistics::PyramidLayerInfo']]],
  ['isvalid',['IsValid',['../classlib_c_z_i_1_1_i_dim_coordinate.html#a92dbe2ec439f6c5c47102c51955039e0',1,'libCZI::IDimCoordinate::IsValid()'],['../classlib_c_z_i_1_1_i_dim_bounds.html#a6b8c29334e22e1f791075027c0afb063',1,'libCZI::IDimBounds::IsValid()'],['../structlib_c_z_i_1_1_int_rect.html#adcabd2e773bd9277a5e30b7c41d90d13',1,'libCZI::IntRect::IsValid()']]]
];

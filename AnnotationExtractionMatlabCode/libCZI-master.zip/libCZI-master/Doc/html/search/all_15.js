var searchData=
[
  ['v',['V',['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424a5206560a306a2e085a437fd258eb57ce',1,'libCZI']]],
  ['value',['value',['../structlib_c_z_i_1_1_dimension_and_value.html#a297b6a1b603c8e8e5ae77d271e93ea15',1,'libCZI::DimensionAndValue']]]
];

var searchData=
[
  ['multi_2dchannel_2dcomposition',['Multi-channel-composition',['../multichannelcomposition.html',1,'']]]
];

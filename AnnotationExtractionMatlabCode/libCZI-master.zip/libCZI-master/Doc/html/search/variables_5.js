var searchData=
[
  ['g',['g',['../structlib_c_z_i_1_1_rgb8_color.html#ac65ccfe0906c981fffe91d03aeb1c5e6',1,'libCZI::Rgb8Color::g()'],['../structlib_c_z_i_1_1_rgb_float_color.html#ac2d9348df01510bd606f011cb4930254',1,'libCZI::RgbFloatColor::g()']]]
];

var searchData=
[
  ['name',['name',['../structlib_c_z_i_1_1_attachment_info.html#a0e68d0e359ff6dc8ae54e39267486a43',1,'libCZI::AttachmentInfo::name()'],['../structlib_c_z_i_1_1_general_document_info.html#afc37e71ba6b59171c877c17749b91aa3',1,'libCZI::GeneralDocumentInfo::name()']]]
];

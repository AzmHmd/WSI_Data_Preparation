var searchData=
[
  ['gamma',['Gamma',['../classlib_c_z_i_1_1_i_display_settings.html#a8e600e80a4999495c1ab1f637ffb94ffad9cdb0f6e0d556347c10a8695545a4b5',1,'libCZI::IDisplaySettings']]],
  ['gray16',['Gray16',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834a2a6ec0dac8730c09dba12f860dbbad12',1,'libCZI']]],
  ['gray32',['Gray32',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834a7f0779c83e549b802dc51d3ee21409fb',1,'libCZI']]],
  ['gray32float',['Gray32Float',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834a775c539daafabbfa29d83576687dd529',1,'libCZI']]],
  ['gray64complexfloat',['Gray64ComplexFloat',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834a062a1aa408f0e6dff16852b6059d50eb',1,'libCZI']]],
  ['gray64float',['Gray64Float',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834a6430601b36b882d0c9d97bfdd83865d9',1,'libCZI']]],
  ['gray8',['Gray8',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834ac8cfe3d00282445878661f32adca48ef',1,'libCZI']]]
];

var searchData=
[
  ['uncompressed',['UnCompressed',['../namespacelib_c_z_i.html#a672959aa909ce27c5a549465200b08fbae7e0de5672fc94ea487936c0de3ff199',1,'libCZI']]],
  ['unlock',['Unlock',['../classlib_c_z_i_1_1_i_bitmap_data.html#a473c706c604fd687fb653bd06f0e0356',1,'libCZI::IBitmapData']]],
  ['unspecified',['Unspecified',['../classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#afac26a03ad8be1d8314911a58b9b08b5a6fcdc090caeade09d0efd6253932b6f5',1,'libCZI::LibCZIAccessorException::Unspecified()'],['../classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2a6fcdc090caeade09d0efd6253932b6f5',1,'libCZI::LibCZIStringParseException::Unspecified()']]],
  ['username',['userName',['../structlib_c_z_i_1_1_general_document_info.html#a2ac0606c9395217d63c586f9bd356f3e',1,'libCZI::GeneralDocumentInfo']]],
  ['using_20libczi',['using libCZI',['../using_naczirlib.html',1,'']]],
  ['utils',['Utils',['../classlib_c_z_i_1_1_utils.html',1,'libCZI']]]
];

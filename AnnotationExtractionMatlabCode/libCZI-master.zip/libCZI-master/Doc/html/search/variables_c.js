var searchData=
[
  ['r',['r',['../structlib_c_z_i_1_1_rgb8_color.html#acdf7d80ba3adccfc7866b4c0f182248c',1,'libCZI::Rgb8Color::r()'],['../structlib_c_z_i_1_1_rgb_float_color.html#a41c20a73ab74d9ade494315511267ef2',1,'libCZI::RgbFloatColor::r()']]],
  ['rating',['rating',['../structlib_c_z_i_1_1_general_document_info.html#a26ded0bae7ffb1bc68fef7f1862c0508',1,'libCZI::GeneralDocumentInfo']]]
];

var searchData=
[
  ['physicalsize',['physicalSize',['../structlib_c_z_i_1_1_sub_block_info.html#abfd40e11bbd325fb760b911588b25b0b',1,'libCZI::SubBlockInfo']]],
  ['pixeltype',['pixelType',['../structlib_c_z_i_1_1_sub_block_info.html#a278ea0802b23ed941cae5f0dbf5dc52c',1,'libCZI::SubBlockInfo']]],
  ['ptrdata',['ptrData',['../structlib_c_z_i_1_1_bitmap_lock_info.html#a1113106a82231213cd4e8980d3106ebd',1,'libCZI::BitmapLockInfo']]],
  ['ptrdataroi',['ptrDataRoi',['../structlib_c_z_i_1_1_bitmap_lock_info.html#ab54e2118992996eacc9ccd8e49397f09',1,'libCZI::BitmapLockInfo']]],
  ['ptrlookuptable',['ptrLookUpTable',['../structlib_c_z_i_1_1_compositors_1_1_channel_info.html#aced547bcca881f7101bcba53b113fe15',1,'libCZI::Compositors::ChannelInfo']]],
  ['pyramidlayerno',['pyramidLayerNo',['../structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#ad6b9ffa4916540dc3749711678cf272b',1,'libCZI::PyramidStatistics::PyramidLayerInfo::pyramidLayerNo()'],['../structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_pyramid_layer_info.html#a8e10d960baf73d757ef512294a360957',1,'libCZI::ISingleChannelPyramidLayerTileAccessor::PyramidLayerInfo::pyramidLayerNo()']]]
];

var searchData=
[
  ['bitmaplockinfo',['BitmapLockInfo',['../structlib_c_z_i_1_1_bitmap_lock_info.html',1,'libCZI']]],
  ['boundingboxes',['BoundingBoxes',['../structlib_c_z_i_1_1_bounding_boxes.html',1,'libCZI']]]
];

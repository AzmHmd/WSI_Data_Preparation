var searchData=
[
  ['rgb8color',['Rgb8Color',['../structlib_c_z_i_1_1_rgb8_color.html',1,'libCZI']]],
  ['rgbfloatcolor',['RgbFloatColor',['../structlib_c_z_i_1_1_rgb_float_color.html',1,'libCZI']]]
];

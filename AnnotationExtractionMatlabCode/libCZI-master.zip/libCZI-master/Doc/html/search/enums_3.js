var searchData=
[
  ['errorcode',['ErrorCode',['../structlib_c_z_i_1_1_lib_c_z_i_c_z_i_parse_exception.html#a32a6c8ab31a657e490e5c605c97efb40',1,'libCZI::LibCZICZIParseException::ErrorCode()'],['../structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60',1,'libCZI::LibCZIInvalidPlaneCoordinateException::ErrorCode()']]],
  ['errortype',['ErrorType',['../classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#afac26a03ad8be1d8314911a58b9b08b5',1,'libCZI::LibCZIAccessorException::ErrorType()'],['../classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2',1,'libCZI::LibCZIStringParseException::ErrorType()']]]
];

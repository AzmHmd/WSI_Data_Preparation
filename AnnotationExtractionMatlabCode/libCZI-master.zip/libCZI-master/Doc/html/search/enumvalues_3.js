var searchData=
[
  ['data',['Data',['../classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108ad89f4242d3c09c1ef3302841226d240d',1,'libCZI::ISubBlock']]],
  ['default',['Default',['../namespacelib_c_z_i.html#a77743727a5f0709a64237e58b9254983a7a1920d61156abc05a60135aefe8bc67',1,'libCZI']]],
  ['duplicatedimension',['DuplicateDimension',['../classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2a6a381f451ea053e25a0e87136e35dd19',1,'libCZI::LibCZIStringParseException']]]
];

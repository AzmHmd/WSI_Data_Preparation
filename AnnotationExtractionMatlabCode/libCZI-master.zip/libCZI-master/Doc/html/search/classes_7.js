var searchData=
[
  ['options',['Options',['../structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_options.html',1,'libCZI::ISingleChannelPyramidLayerTileAccessor::Options'],['../structlib_c_z_i_1_1_i_single_channel_tile_accessor_1_1_options.html',1,'libCZI::ISingleChannelTileAccessor::Options'],['../structlib_c_z_i_1_1_i_single_channel_scaling_tile_accessor_1_1_options.html',1,'libCZI::ISingleChannelScalingTileAccessor::Options']]]
];

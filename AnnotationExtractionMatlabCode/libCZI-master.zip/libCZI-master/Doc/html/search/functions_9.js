var searchData=
[
  ['read',['Read',['../classlib_c_z_i_1_1_i_stream.html#ae275276d0da5082a3711527ddfedfd9f',1,'libCZI::IStream']]],
  ['readattachment',['ReadAttachment',['../classlib_c_z_i_1_1_i_attachment_repository.html#a8f0a7a926425e39017559a95207e2d5d',1,'libCZI::IAttachmentRepository']]],
  ['readmetadatasegment',['ReadMetadataSegment',['../classlib_c_z_i_1_1_i_c_z_i_reader.html#a9dbab9ddaa7ae4bcfce3c64ed5eea82d',1,'libCZI::ICZIReader']]],
  ['readsubblock',['ReadSubBlock',['../classlib_c_z_i_1_1_i_sub_block_repository.html#afd2d9c375554492cf499c97ae49aa50b',1,'libCZI::ISubBlockRepository']]]
];

var searchData=
[
  ['uncompressed',['UnCompressed',['../namespacelib_c_z_i.html#a672959aa909ce27c5a549465200b08fbae7e0de5672fc94ea487936c0de3ff199',1,'libCZI']]],
  ['unspecified',['Unspecified',['../classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#afac26a03ad8be1d8314911a58b9b08b5a6fcdc090caeade09d0efd6253932b6f5',1,'libCZI::LibCZIAccessorException::Unspecified()'],['../classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2a6fcdc090caeade09d0efd6253932b6f5',1,'libCZI::LibCZIStringParseException::Unspecified()']]]
];

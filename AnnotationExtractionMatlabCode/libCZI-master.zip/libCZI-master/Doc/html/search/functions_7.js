var searchData=
[
  ['open',['Open',['../classlib_c_z_i_1_1_i_c_z_i_reader.html#ae3b1a8fabae6b70480f0855fe374ecd9',1,'libCZI::ICZIReader']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../namespacelib_c_z_i.html#aee5b36178903cd959cd840973309c4bb',1,'libCZI::operator&lt;&lt;(std::ostream &amp;os, const IntRect &amp;rect)'],['../namespacelib_c_z_i.html#aa572fb9812d1569dc1afbcef03fbc3ee',1,'libCZI::operator&lt;&lt;(std::ostream &amp;os, const IntSize &amp;size)']]],
  ['operator_3d',['operator=',['../classlib_c_z_i_1_1_scoped_bitmap_locker.html#aaaf38bc85de0190783597ccf3620fd85',1,'libCZI::ScopedBitmapLocker']]]
];

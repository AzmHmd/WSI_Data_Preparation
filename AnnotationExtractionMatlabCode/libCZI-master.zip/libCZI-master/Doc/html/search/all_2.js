var searchData=
[
  ['b',['b',['../structlib_c_z_i_1_1_i_display_settings_1_1_cubic_spline_coefficients.html#a7c7574bd8a5c40eeda3d170ec55a16d3',1,'libCZI::IDisplaySettings::CubicSplineCoefficients::b()'],['../structlib_c_z_i_1_1_rgb8_color.html#a6d3a9bfebe412e8febb32e8ea313ee40',1,'libCZI::Rgb8Color::b()'],['../structlib_c_z_i_1_1_rgb_float_color.html#a599c4b00addc9c1cf88c9ef943903064',1,'libCZI::RgbFloatColor::b()'],['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424a9d5ed678fe57bcca610140957afab571',1,'libCZI::B()']]],
  ['backgroundcolor',['backGroundColor',['../structlib_c_z_i_1_1_i_single_channel_tile_accessor_1_1_options.html#a55c96574134736e35182931d4bee4636',1,'libCZI::ISingleChannelTileAccessor::Options::backGroundColor()'],['../structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_options.html#a6d5fe02340cf9e640b0c7a4e994e4c3a',1,'libCZI::ISingleChannelPyramidLayerTileAccessor::Options::backGroundColor()'],['../structlib_c_z_i_1_1_i_single_channel_scaling_tile_accessor_1_1_options.html#a2d62a4b7e8dd4edc3d4419c2dc3e4901',1,'libCZI::ISingleChannelScalingTileAccessor::Options::backGroundColor()']]],
  ['bgr192complexfloat',['Bgr192ComplexFloat',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834aa48ea83023a8044662550b0871fa7878',1,'libCZI']]],
  ['bgr24',['Bgr24',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834ab2c7c7f5592a2d285184d73d3b619173',1,'libCZI']]],
  ['bgr48',['Bgr48',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834a7db8f5fba48387a28c10c0f27eea31a0',1,'libCZI']]],
  ['bgr96float',['Bgr96Float',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834ad42330ab003d3ccd0e9bfb8dcb59fe78',1,'libCZI']]],
  ['bgra32',['Bgra32',['../namespacelib_c_z_i.html#abf8ce12ab88b06c8b3b47efbb5e2e834a2c5ed55e4aac8b7ca717880f2267896a',1,'libCZI']]],
  ['bitmaplockinfo',['BitmapLockInfo',['../structlib_c_z_i_1_1_bitmap_lock_info.html',1,'libCZI']]],
  ['blackpoint',['blackPoint',['../structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a108977b9e981ecff39b65add4bceddb2',1,'libCZI::Compositors::ChannelInfo']]],
  ['boundingbox',['boundingBox',['../structlib_c_z_i_1_1_bounding_boxes.html#abc2beea033eba496b26cbfdb4b16ced6',1,'libCZI::BoundingBoxes::boundingBox()'],['../structlib_c_z_i_1_1_sub_block_statistics.html#a924c2adf7f3e132470dfeb06ea1e958c',1,'libCZI::SubBlockStatistics::boundingBox()']]],
  ['boundingboxes',['BoundingBoxes',['../structlib_c_z_i_1_1_bounding_boxes.html',1,'libCZI']]],
  ['boundingboxlayer0',['boundingBoxLayer0',['../structlib_c_z_i_1_1_bounding_boxes.html#a6e0e45a2c8bc35fe10463437dc8b9509',1,'libCZI::BoundingBoxes']]],
  ['boundingboxlayer0only',['boundingBoxLayer0Only',['../structlib_c_z_i_1_1_sub_block_statistics.html#a5256d470970ed24507b6bd1fadf32096',1,'libCZI::SubBlockStatistics']]],
  ['building_20libczi',['Building libCZI',['../buildinglib_c_z_i.html',1,'']]]
];

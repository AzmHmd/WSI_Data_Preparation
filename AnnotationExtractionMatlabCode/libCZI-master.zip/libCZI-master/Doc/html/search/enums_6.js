var searchData=
[
  ['memblktype',['MemBlkType',['../classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108',1,'libCZI::ISubBlock::MemBlkType()'],['../classlib_c_z_i_1_1_i_metadata_segment.html#a3acd5e2bf5161629f1ee56ecef9b3b72',1,'libCZI::IMetadataSegment::MemBlkType()']]]
];

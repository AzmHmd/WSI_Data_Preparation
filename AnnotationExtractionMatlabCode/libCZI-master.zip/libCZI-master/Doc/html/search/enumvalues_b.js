var searchData=
[
  ['notenoughdata',['NotEnoughData',['../structlib_c_z_i_1_1_lib_c_z_i_c_z_i_parse_exception.html#a32a6c8ab31a657e490e5c605c97efb40ab6e495eeaee7cdf1bac313472e4681ac',1,'libCZI::LibCZICZIParseException']]]
];

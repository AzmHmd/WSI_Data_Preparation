var searchData=
[
  ['parse',['Parse',['../classlib_c_z_i_1_1_c_dim_coordinate.html#a684c17ad37de1e817c660e89e704d81e',1,'libCZI::CDimCoordinate']]],
  ['pixeltypetoinformalstring',['PixelTypeToInformalString',['../classlib_c_z_i_1_1_utils.html#a00d20fac95c23043438c9326eb10bf53',1,'libCZI::Utils']]]
];

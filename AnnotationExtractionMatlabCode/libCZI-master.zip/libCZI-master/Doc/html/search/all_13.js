var searchData=
[
  ['t',['T',['../namespacelib_c_z_i.html#a55049658acf59d0eddfaebcad16df424ab9ece18c950afbfa6b0fdbfa4ff731d3',1,'libCZI']]],
  ['tinting',['tinting',['../structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a5bc342e6d105188d423110cbbd48af87',1,'libCZI::Compositors::ChannelInfo']]],
  ['tintingcolor',['TintingColor',['../structlib_c_z_i_1_1_compositors_1_1_tinting_color.html',1,'libCZI::Compositors']]],
  ['title',['title',['../structlib_c_z_i_1_1_general_document_info.html#ab35797e1b6c3a8e5c8476b43672180bc',1,'libCZI::GeneralDocumentInfo']]],
  ['todos',['Todos',['../todos.html',1,'']]],
  ['trydeterminepixeltypeforchannel',['TryDeterminePixelTypeForChannel',['../classlib_c_z_i_1_1_utils.html#ad105cc3a3791e6dd269116de0f71de04',1,'libCZI::Utils']]],
  ['trygetgamma',['TryGetGamma',['../classlib_c_z_i_1_1_i_channel_display_setting.html#a37a0c8e3159e6a5e3a9cd0c22b90fd2f',1,'libCZI::IChannelDisplaySetting']]],
  ['trygetinterval',['TryGetInterval',['../classlib_c_z_i_1_1_i_dim_bounds.html#a7f42cf193370731a6b21ae5d2d6fa78e',1,'libCZI::IDimBounds::TryGetInterval()'],['../classlib_c_z_i_1_1_c_dim_bounds.html#abf42285e28ddc4843556f88b2292c494',1,'libCZI::CDimBounds::TryGetInterval()']]],
  ['trygetposition',['TryGetPosition',['../classlib_c_z_i_1_1_i_dim_coordinate.html#a3b1c18f0102bd5635b3cd9cc3fba69d2',1,'libCZI::IDimCoordinate::TryGetPosition()'],['../classlib_c_z_i_1_1_c_dim_coordinate.html#af7bc7e775a5971d46550e45ebf2b2ba7',1,'libCZI::CDimCoordinate::TryGetPosition()']]],
  ['trygetsplinecontrolpoints',['TryGetSplineControlPoints',['../classlib_c_z_i_1_1_i_channel_display_setting.html#ae8a2192fd92015fc6ce59958b598a8cb',1,'libCZI::IChannelDisplaySetting']]],
  ['trygetsplinedata',['TryGetSplineData',['../classlib_c_z_i_1_1_i_channel_display_setting.html#ae3779bf0fb5b48c8ee3549e2ebb3947f',1,'libCZI::IChannelDisplaySetting']]],
  ['trygetsubblockinfoofarbitrarysubblockinchannel',['TryGetSubBlockInfoOfArbitrarySubBlockInChannel',['../classlib_c_z_i_1_1_i_sub_block_repository.html#ae557269ff1dcc03bacc21610b17d2104',1,'libCZI::ISubBlockRepository']]],
  ['trygettintingcolorrgb8',['TryGetTintingColorRgb8',['../classlib_c_z_i_1_1_i_channel_display_setting.html#a7fd49b4a914738b4640eedef351cdd02',1,'libCZI::IChannelDisplaySetting']]]
];

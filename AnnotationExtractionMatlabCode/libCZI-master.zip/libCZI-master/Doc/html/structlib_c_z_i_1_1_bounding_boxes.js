var structlib_c_z_i_1_1_bounding_boxes =
[
    [ "boundingBox", "structlib_c_z_i_1_1_bounding_boxes.html#abc2beea033eba496b26cbfdb4b16ced6", null ],
    [ "boundingBoxLayer0", "structlib_c_z_i_1_1_bounding_boxes.html#a6e0e45a2c8bc35fe10463437dc8b9509", null ]
];
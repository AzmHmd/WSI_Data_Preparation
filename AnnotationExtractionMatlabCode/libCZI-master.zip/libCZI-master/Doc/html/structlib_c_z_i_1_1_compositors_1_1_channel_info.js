var structlib_c_z_i_1_1_compositors_1_1_channel_info =
[
    [ "Clear", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a6791d9d03a12930a8958e4e1938254ad", null ],
    [ "blackPoint", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a108977b9e981ecff39b65add4bceddb2", null ],
    [ "enableTinting", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a55842ad5f759439b4e7909b19a3e10ad", null ],
    [ "lookUpTableElementCount", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a2d347a638359b163913fe14205725a55", null ],
    [ "ptrLookUpTable", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#aced547bcca881f7101bcba53b113fe15", null ],
    [ "tinting", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a5bc342e6d105188d423110cbbd48af87", null ],
    [ "weight", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#a2a049e26e597abd995dcf860f45f0d3e", null ],
    [ "whitePoint", "structlib_c_z_i_1_1_compositors_1_1_channel_info.html#acd5158e2c9011e0d5af98363c89d6a96", null ]
];
var structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception =
[
    [ "ErrorCode", "structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60", [
      [ "SurplusDimension", "structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60a2387177c5eeb2b0165fb975f4b741c55", null ],
      [ "MissingDimension", "structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60a06a04b63fba5058c3dc36269ef6dfaaa", null ],
      [ "InvalidDimension", "structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60a32718a726c2956f702be80643045a4e1", null ],
      [ "CoordinateOutOfRange", "structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a2e22a8936930f8e8de4b874764407b60a4a35479ed0f04e5d5ea428427869570b", null ]
    ] ],
    [ "LibCZIInvalidPlaneCoordinateException", "structlib_c_z_i_1_1_lib_c_z_i_invalid_plane_coordinate_exception.html#a574543a1bbfb24a9e01f3d3cb4666318", null ]
];
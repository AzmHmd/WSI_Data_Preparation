var classlib_c_z_i_1_1_i_czi_metadata =
[
    [ "~ICziMetadata", "classlib_c_z_i_1_1_i_czi_metadata.html#a84be56bdcd9036c902c4d07584a78c0e", null ],
    [ "GetDocumentInfo", "classlib_c_z_i_1_1_i_czi_metadata.html#adf1a44d893d1f1aac6639bc39edda5af", null ],
    [ "GetXml", "classlib_c_z_i_1_1_i_czi_metadata.html#afd73a12ac5a04a725ad9f3d130f4e2de", null ]
];
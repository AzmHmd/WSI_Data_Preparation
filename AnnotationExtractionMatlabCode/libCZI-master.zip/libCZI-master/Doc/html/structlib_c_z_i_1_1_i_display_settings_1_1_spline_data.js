var structlib_c_z_i_1_1_i_display_settings_1_1_spline_data =
[
    [ "coefficients", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_data.html#a2daa2f1b10f4bf574f13e4fd699c5b33", null ],
    [ "xPos", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_data.html#a745dd0b033824f68be93d3b038d6ed41", null ]
];
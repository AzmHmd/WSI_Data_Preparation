var classlib_c_z_i_1_1_i_dimension_info =
[
    [ "~IDimensionInfo", "classlib_c_z_i_1_1_i_dimension_info.html#af7bb919c2521d73eccef7f2dc9d49f01", null ],
    [ "GetDimension", "classlib_c_z_i_1_1_i_dimension_info.html#a3aef5c6762b0142fc2665d342e939a9d", null ],
    [ "GetInterval", "classlib_c_z_i_1_1_i_dimension_info.html#a2e04b30f6e8877c3ae080b01e5ff994e", null ]
];
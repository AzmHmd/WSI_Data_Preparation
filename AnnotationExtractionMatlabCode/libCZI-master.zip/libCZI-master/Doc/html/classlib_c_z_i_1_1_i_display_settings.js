var classlib_c_z_i_1_1_i_display_settings =
[
    [ "CubicSplineCoefficients", "structlib_c_z_i_1_1_i_display_settings_1_1_cubic_spline_coefficients.html", "structlib_c_z_i_1_1_i_display_settings_1_1_cubic_spline_coefficients" ],
    [ "SplineControlPoint", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_control_point.html", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_control_point" ],
    [ "SplineData", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_data.html", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_data" ],
    [ "GradationCurveMode", "classlib_c_z_i_1_1_i_display_settings.html#a8e600e80a4999495c1ab1f637ffb94ff", [
      [ "Linear", "classlib_c_z_i_1_1_i_display_settings.html#a8e600e80a4999495c1ab1f637ffb94ffa32a843da6ea40ab3b17a3421ccdf671b", null ],
      [ "Gamma", "classlib_c_z_i_1_1_i_display_settings.html#a8e600e80a4999495c1ab1f637ffb94ffad9cdb0f6e0d556347c10a8695545a4b5", null ],
      [ "Spline", "classlib_c_z_i_1_1_i_display_settings.html#a8e600e80a4999495c1ab1f637ffb94ffa4cff6afc4963881749f7742fbb4d1392", null ]
    ] ],
    [ "~IDisplaySettings", "classlib_c_z_i_1_1_i_display_settings.html#ad4a4581092eae4a24310c16d3af4f13c", null ],
    [ "EnumChannels", "classlib_c_z_i_1_1_i_display_settings.html#af19480abbb7905656e5411bd34d0506d", null ],
    [ "GetChannelDisplaySettings", "classlib_c_z_i_1_1_i_display_settings.html#ad67ab35e429286d38dd11245eda3dc4c", null ]
];
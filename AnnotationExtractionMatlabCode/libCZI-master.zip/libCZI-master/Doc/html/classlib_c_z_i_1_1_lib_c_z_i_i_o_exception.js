var classlib_c_z_i_1_1_lib_c_z_i_i_o_exception =
[
    [ "LibCZIIOException", "classlib_c_z_i_1_1_lib_c_z_i_i_o_exception.html#aa8912797c22c48afee6e24bdb1e03008", null ],
    [ "GetOffset", "classlib_c_z_i_1_1_lib_c_z_i_i_o_exception.html#a74781fd4547321f2e81e04028f385fd8", null ],
    [ "GetSize", "classlib_c_z_i_1_1_lib_c_z_i_i_o_exception.html#affd1d9993181dbbed726234b01c1eca7", null ]
];
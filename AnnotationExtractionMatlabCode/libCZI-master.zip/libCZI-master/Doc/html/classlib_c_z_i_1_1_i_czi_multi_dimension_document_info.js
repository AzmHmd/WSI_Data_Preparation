var classlib_c_z_i_1_1_i_czi_multi_dimension_document_info =
[
    [ "~ICziMultiDimensionDocumentInfo", "classlib_c_z_i_1_1_i_czi_multi_dimension_document_info.html#ae3a5a604d287b6c0d9eb645b59153eab", null ],
    [ "EnumDimensions", "classlib_c_z_i_1_1_i_czi_multi_dimension_document_info.html#a23f7b26bd323732fac0d190e9b38b6e3", null ],
    [ "GetDimensionInfo", "classlib_c_z_i_1_1_i_czi_multi_dimension_document_info.html#a1e5d72c39dc22f99e1ee27b21055d3ea", null ],
    [ "GetDimensions", "classlib_c_z_i_1_1_i_czi_multi_dimension_document_info.html#aede2d6dd6e991151afff77b0cb96834a", null ],
    [ "GetDisplaySettings", "classlib_c_z_i_1_1_i_czi_multi_dimension_document_info.html#a8aff8239a31b047b737f80be0b2c9bda", null ],
    [ "GetGeneralDocumentInfo", "classlib_c_z_i_1_1_i_czi_multi_dimension_document_info.html#aefea877fc65e9510d9a3127e366cb85c", null ],
    [ "GetScalingInfo", "classlib_c_z_i_1_1_i_czi_multi_dimension_document_info.html#ae94341e3e5824b8c1d5c84928ced2e6c", null ]
];
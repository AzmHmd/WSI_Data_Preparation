var classlib_c_z_i_1_1_i_sub_block =
[
    [ "MemBlkType", "classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108", [
      [ "Metadata", "classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108ada66dacad65a36fd265a7a2dacae197c", null ],
      [ "Data", "classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108ad89f4242d3c09c1ef3302841226d240d", null ],
      [ "Attachment", "classlib_c_z_i_1_1_i_sub_block.html#a4dc4926ea65d8d20310b8b79ea76e108ab60de398d6a7a2fe1c4c9585572b3ef1", null ]
    ] ],
    [ "~ISubBlock", "classlib_c_z_i_1_1_i_sub_block.html#a6edf53d07376b0b7adce81755f5ba93c", null ],
    [ "CreateBitmap", "classlib_c_z_i_1_1_i_sub_block.html#af2059d1f270f3e4349244403fa7dd71c", null ],
    [ "DangerousGetRawData", "classlib_c_z_i_1_1_i_sub_block.html#a6f84a58437af59bac64a6147369ddae4", null ],
    [ "DangerousGetRawData", "classlib_c_z_i_1_1_i_sub_block.html#acd9396cc5d366de99b37a26c98031d66", null ],
    [ "GetRawData", "classlib_c_z_i_1_1_i_sub_block.html#a55ec2c117050df253367661f9cd606cf", null ],
    [ "GetSubBlockInfo", "classlib_c_z_i_1_1_i_sub_block.html#a557108549db08e25b1df1ef8fae37a07", null ]
];
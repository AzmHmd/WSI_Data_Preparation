var classlib_c_z_i_1_1_i_metadata_segment =
[
    [ "MemBlkType", "classlib_c_z_i_1_1_i_metadata_segment.html#a3acd5e2bf5161629f1ee56ecef9b3b72", [
      [ "XmlMetadata", "classlib_c_z_i_1_1_i_metadata_segment.html#a3acd5e2bf5161629f1ee56ecef9b3b72a33f06811a574191b45596337520b8984", null ],
      [ "Attachment", "classlib_c_z_i_1_1_i_metadata_segment.html#a3acd5e2bf5161629f1ee56ecef9b3b72a61a22550a6ebb48d975667b448757bec", null ]
    ] ],
    [ "~IMetadataSegment", "classlib_c_z_i_1_1_i_metadata_segment.html#a9c07f18ed0cb14d6909ad5f50c9c17af", null ],
    [ "CreateMetaFromMetadataSegment", "classlib_c_z_i_1_1_i_metadata_segment.html#a62a0e7c30613b6f4dac3bf1ca80ab8bc", null ],
    [ "DangerousGetRawData", "classlib_c_z_i_1_1_i_metadata_segment.html#a749349eab738a5fd7e5bce2e67440953", null ],
    [ "GetRawData", "classlib_c_z_i_1_1_i_metadata_segment.html#a5e6fd2f7ce81245075df9bc6a522a325", null ]
];
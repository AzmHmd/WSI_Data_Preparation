var classlib_c_z_i_1_1_c_dim_coordinate =
[
    [ "CDimCoordinate", "classlib_c_z_i_1_1_c_dim_coordinate.html#a51d381d8965a8d10c6d0295593bc3885", null ],
    [ "CDimCoordinate", "classlib_c_z_i_1_1_c_dim_coordinate.html#a513ae54e9dc32c0c19040b94add75e80", null ],
    [ "CDimCoordinate", "classlib_c_z_i_1_1_c_dim_coordinate.html#a95be8c1ca51e6bf4e5efc4f23a027148", null ],
    [ "Clear", "classlib_c_z_i_1_1_c_dim_coordinate.html#abfffd501e6cb4818a4b0454920b866ef", null ],
    [ "EnumValidDimensions", "classlib_c_z_i_1_1_c_dim_coordinate.html#a65d3104fbc171cdab0cd53616df13f8e", null ],
    [ "Set", "classlib_c_z_i_1_1_c_dim_coordinate.html#a9f6d967df6c2040e395c0710e8374909", null ],
    [ "TryGetPosition", "classlib_c_z_i_1_1_c_dim_coordinate.html#af7bc7e775a5971d46550e45ebf2b2ba7", null ]
];
var structlib_c_z_i_1_1_rgb8_color =
[
    [ "b", "structlib_c_z_i_1_1_rgb8_color.html#a6d3a9bfebe412e8febb32e8ea313ee40", null ],
    [ "g", "structlib_c_z_i_1_1_rgb8_color.html#ac65ccfe0906c981fffe91d03aeb1c5e6", null ],
    [ "r", "structlib_c_z_i_1_1_rgb8_color.html#acdf7d80ba3adccfc7866b4c0f182248c", null ]
];
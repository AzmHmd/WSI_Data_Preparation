var classlib_c_z_i_1_1_i_dim_coordinate =
[
    [ "IsValid", "classlib_c_z_i_1_1_i_dim_coordinate.html#a92dbe2ec439f6c5c47102c51955039e0", null ],
    [ "TryGetPosition", "classlib_c_z_i_1_1_i_dim_coordinate.html#a3b1c18f0102bd5635b3cd9cc3fba69d2", null ]
];
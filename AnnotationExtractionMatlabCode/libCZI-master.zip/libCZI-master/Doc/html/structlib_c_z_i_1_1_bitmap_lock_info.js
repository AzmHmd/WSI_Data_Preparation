var structlib_c_z_i_1_1_bitmap_lock_info =
[
    [ "ptrData", "structlib_c_z_i_1_1_bitmap_lock_info.html#a1113106a82231213cd4e8980d3106ebd", null ],
    [ "ptrDataRoi", "structlib_c_z_i_1_1_bitmap_lock_info.html#ab54e2118992996eacc9ccd8e49397f09", null ],
    [ "size", "structlib_c_z_i_1_1_bitmap_lock_info.html#a109f8d69b48bc4398861217c375dee1b", null ],
    [ "stride", "structlib_c_z_i_1_1_bitmap_lock_info.html#a8e7259142382ec0ad887c974d27775b6", null ]
];
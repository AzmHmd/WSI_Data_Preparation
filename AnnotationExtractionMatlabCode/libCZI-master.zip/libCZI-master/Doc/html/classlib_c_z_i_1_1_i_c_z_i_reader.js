var classlib_c_z_i_1_1_i_c_z_i_reader =
[
    [ "Close", "classlib_c_z_i_1_1_i_c_z_i_reader.html#aef45f08b7e9cec6a40ab7ee50285eaba", null ],
    [ "CreateAccessor", "classlib_c_z_i_1_1_i_c_z_i_reader.html#a3fe8c576a58058e9bbebb9c9fd5633b0", null ],
    [ "CreateSingleChannelPyramidLayerTileAccessor", "classlib_c_z_i_1_1_i_c_z_i_reader.html#af7f45db86ad27a90394bf036bfa4e985", null ],
    [ "CreateSingleChannelScalingTileAccessor", "classlib_c_z_i_1_1_i_c_z_i_reader.html#a481f10b35f8f9e8afa05b0e0a3f94d59", null ],
    [ "CreateSingleChannelTileAccessor", "classlib_c_z_i_1_1_i_c_z_i_reader.html#a41d07167b2005205fc15d6d64ec280b8", null ],
    [ "Open", "classlib_c_z_i_1_1_i_c_z_i_reader.html#ae3b1a8fabae6b70480f0855fe374ecd9", null ],
    [ "ReadMetadataSegment", "classlib_c_z_i_1_1_i_c_z_i_reader.html#a9dbab9ddaa7ae4bcfce3c64ed5eea82d", null ]
];
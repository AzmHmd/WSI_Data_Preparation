var classlib_c_z_i_1_1_lib_c_z_i_accessor_exception =
[
    [ "ErrorType", "classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#afac26a03ad8be1d8314911a58b9b08b5", [
      [ "CouldntDeterminePixelType", "classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#afac26a03ad8be1d8314911a58b9b08b5ab9a3da346ec292af4ab30323d51475a7", null ],
      [ "Unspecified", "classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#afac26a03ad8be1d8314911a58b9b08b5a6fcdc090caeade09d0efd6253932b6f5", null ]
    ] ],
    [ "LibCZIAccessorException", "classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#a4eb949381be1d9ca7e1f1b65f5fdacd0", null ],
    [ "GetErrorType", "classlib_c_z_i_1_1_lib_c_z_i_accessor_exception.html#a8d5241a5d61e5d2ae97a6ee4c8f3e39e", null ]
];
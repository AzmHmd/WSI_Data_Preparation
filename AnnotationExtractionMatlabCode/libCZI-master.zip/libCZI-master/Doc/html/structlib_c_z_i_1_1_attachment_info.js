var structlib_c_z_i_1_1_attachment_info =
[
    [ "contentFileType", "structlib_c_z_i_1_1_attachment_info.html#a0cd022f5e1f564d410165faeb72eadbb", null ],
    [ "contentGuid", "structlib_c_z_i_1_1_attachment_info.html#a7be40455831774e65cd394592af97220", null ],
    [ "name", "structlib_c_z_i_1_1_attachment_info.html#a0e68d0e359ff6dc8ae54e39267486a43", null ]
];
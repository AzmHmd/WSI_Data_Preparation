var structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_pyramid_layer_info =
[
    [ "minificationFactor", "structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_pyramid_layer_info.html#a533419024a6645305568efbd42100b45", null ],
    [ "pyramidLayerNo", "structlib_c_z_i_1_1_i_single_channel_pyramid_layer_tile_accessor_1_1_pyramid_layer_info.html#a8e10d960baf73d757ef512294a360957", null ]
];
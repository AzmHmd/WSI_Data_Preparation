var structlib_c_z_i_1_1_sub_block_info =
[
    [ "GetZoom", "structlib_c_z_i_1_1_sub_block_info.html#ad39548c987b6e8d80730eb29c252dfef", null ],
    [ "coordinate", "structlib_c_z_i_1_1_sub_block_info.html#ae4acf2922fe594327d1c6fbfb2062781", null ],
    [ "logicalRect", "structlib_c_z_i_1_1_sub_block_info.html#acca674e34ebccc46b43ee6a429c14eda", null ],
    [ "mIndex", "structlib_c_z_i_1_1_sub_block_info.html#a413dbeb605db073feaf280256ddc9715", null ],
    [ "mode", "structlib_c_z_i_1_1_sub_block_info.html#a0e293a3e7ea6188e3df08ae74c16221f", null ],
    [ "physicalSize", "structlib_c_z_i_1_1_sub_block_info.html#abfd40e11bbd325fb760b911588b25b0b", null ],
    [ "pixelType", "structlib_c_z_i_1_1_sub_block_info.html#a278ea0802b23ed941cae5f0dbf5dc52c", null ]
];
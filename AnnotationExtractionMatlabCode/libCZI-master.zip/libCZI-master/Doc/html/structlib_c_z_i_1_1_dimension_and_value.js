var structlib_c_z_i_1_1_dimension_and_value =
[
    [ "dimension", "structlib_c_z_i_1_1_dimension_and_value.html#a0274b97af7cdb3f56231868fb22e92b1", null ],
    [ "value", "structlib_c_z_i_1_1_dimension_and_value.html#a297b6a1b603c8e8e5ae77d271e93ea15", null ]
];
var structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_statistics =
[
    [ "count", "structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_statistics.html#a9622c14764217c603d3e50565c768702", null ],
    [ "layerInfo", "structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_statistics.html#aebd2aa3ece769861674d89007717aa4a", null ]
];
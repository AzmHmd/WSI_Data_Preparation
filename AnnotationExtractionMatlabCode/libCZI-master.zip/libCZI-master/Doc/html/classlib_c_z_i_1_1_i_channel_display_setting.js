var classlib_c_z_i_1_1_i_channel_display_setting =
[
    [ "~IChannelDisplaySetting", "classlib_c_z_i_1_1_i_channel_display_setting.html#a32fdf2c4a31780d4ba1bc62149dd7789", null ],
    [ "GetBlackWhitePoint", "classlib_c_z_i_1_1_i_channel_display_setting.html#a1172fdc6f7c3131d5e6ddf6ab35c6f85", null ],
    [ "GetGradationCurveMode", "classlib_c_z_i_1_1_i_channel_display_setting.html#abcee850366caccfb3245c84ea6f71287", null ],
    [ "GetIsEnabled", "classlib_c_z_i_1_1_i_channel_display_setting.html#a874cb106b686e6f4b7fad2f6dd1b3eed", null ],
    [ "GetWeight", "classlib_c_z_i_1_1_i_channel_display_setting.html#ad4b5a8fed9cad0b28acbbfed7736a8d0", null ],
    [ "TryGetGamma", "classlib_c_z_i_1_1_i_channel_display_setting.html#a37a0c8e3159e6a5e3a9cd0c22b90fd2f", null ],
    [ "TryGetSplineControlPoints", "classlib_c_z_i_1_1_i_channel_display_setting.html#ae8a2192fd92015fc6ce59958b598a8cb", null ],
    [ "TryGetSplineData", "classlib_c_z_i_1_1_i_channel_display_setting.html#ae3779bf0fb5b48c8ee3549e2ebb3947f", null ],
    [ "TryGetTintingColorRgb8", "classlib_c_z_i_1_1_i_channel_display_setting.html#a7fd49b4a914738b4640eedef351cdd02", null ]
];
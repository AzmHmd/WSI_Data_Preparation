var classlib_c_z_i_1_1_i_attachment_repository =
[
    [ "EnumerateAttachments", "classlib_c_z_i_1_1_i_attachment_repository.html#a38f1c13a03e2dd8887d911be2c1b892b", null ],
    [ "EnumerateSubset", "classlib_c_z_i_1_1_i_attachment_repository.html#acc6b932d8d587bb8399c0236c1c29a55", null ],
    [ "ReadAttachment", "classlib_c_z_i_1_1_i_attachment_repository.html#a8f0a7a926425e39017559a95207e2d5d", null ]
];
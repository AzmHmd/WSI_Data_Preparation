var classlib_c_z_i_1_1_i_stream =
[
    [ "~IStream", "classlib_c_z_i_1_1_i_stream.html#a1c8b2df4bb27efebf83fe94c0b50d128", null ],
    [ "Read", "classlib_c_z_i_1_1_i_stream.html#ae275276d0da5082a3711527ddfedfd9f", null ]
];
var structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info =
[
    [ "IsLayer0", "structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#a9cafde3541c9752058dcbeaaa73d4686", null ],
    [ "IsNotIdentifiedAsPyramidLayer", "structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#afc9992be68effd61fa8ff828c3fe467d", null ],
    [ "minificationFactor", "structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#a397023f140015ffb12dc87bdfd721dc1", null ],
    [ "pyramidLayerNo", "structlib_c_z_i_1_1_pyramid_statistics_1_1_pyramid_layer_info.html#ad6b9ffa4916540dc3749711678cf272b", null ]
];
var structlib_c_z_i_1_1_i_display_settings_1_1_spline_control_point =
[
    [ "x", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_control_point.html#a1978764701b7179c6e5fd045dc88fe9a", null ],
    [ "y", "structlib_c_z_i_1_1_i_display_settings_1_1_spline_control_point.html#a3cce749fa57f428f61d93f55c617becb", null ]
];
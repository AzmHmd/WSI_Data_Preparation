var structlib_c_z_i_1_1_scaling_info =
[
    [ "ScalingInfo", "structlib_c_z_i_1_1_scaling_info.html#a5faab7e185b27b1154088631d83b6a0f", null ],
    [ "scaleX", "structlib_c_z_i_1_1_scaling_info.html#ad78c8dd0c50767ea6004f513379744a3", null ],
    [ "scaleY", "structlib_c_z_i_1_1_scaling_info.html#a1e3eaed2c197331a7f47db7c6a89d930", null ],
    [ "scaleZ", "structlib_c_z_i_1_1_scaling_info.html#a51209385ef9ee539c5f1fad0a507f63b", null ]
];
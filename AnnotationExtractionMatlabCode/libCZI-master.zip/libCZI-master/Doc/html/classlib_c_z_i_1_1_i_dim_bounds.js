var classlib_c_z_i_1_1_i_dim_bounds =
[
    [ "IsValid", "classlib_c_z_i_1_1_i_dim_bounds.html#a6b8c29334e22e1f791075027c0afb063", null ],
    [ "TryGetInterval", "classlib_c_z_i_1_1_i_dim_bounds.html#a7f42cf193370731a6b21ae5d2d6fa78e", null ]
];
var classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception =
[
    [ "ErrorType", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2", [
      [ "InvalidSyntax", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2afc52000b95d50ca5da692212b69e61c2", null ],
      [ "DuplicateDimension", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2a6a381f451ea053e25a0e87136e35dd19", null ],
      [ "FromGreaterThanTo", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2aff73eb7f68565f16f023d1c074816ea5", null ],
      [ "Unspecified", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a42ecdd87f0e6f47ca0accda1b90497d2a6fcdc090caeade09d0efd6253932b6f5", null ]
    ] ],
    [ "LibCZIStringParseException", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#a6bcf9792770dc4cbe17f8a8a0d665b7d", null ],
    [ "GetErrorType", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#abf18d7eb523f8aa3ed8b110e2cc170a2", null ],
    [ "GetNumberOfCharsParsedOk", "classlib_c_z_i_1_1_lib_c_z_i_string_parse_exception.html#ab9f93bffdad9f93cec7d69f66ce57dfc", null ]
];
var structlib_c_z_i_1_1_compositors_1_1_tinting_color =
[
    [ "color", "structlib_c_z_i_1_1_compositors_1_1_tinting_color.html#ac703e2b5d55edd041a3fc4974709a3ce", null ]
];
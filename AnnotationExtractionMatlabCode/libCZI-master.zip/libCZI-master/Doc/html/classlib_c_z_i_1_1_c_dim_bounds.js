var classlib_c_z_i_1_1_c_dim_bounds =
[
    [ "CDimBounds", "classlib_c_z_i_1_1_c_dim_bounds.html#a86cb06505f8ac0cf75a9258f49ef58dc", null ],
    [ "CDimBounds", "classlib_c_z_i_1_1_c_dim_bounds.html#aae378201c633fa582d3af0740b1b634a", null ],
    [ "Clear", "classlib_c_z_i_1_1_c_dim_bounds.html#a96a5f7ec6f13896998eff3c7d2c7e5bf", null ],
    [ "Clear", "classlib_c_z_i_1_1_c_dim_bounds.html#a7e84b9c941feefe65e2a4005a3c58e14", null ],
    [ "EnumValidDimensions", "classlib_c_z_i_1_1_c_dim_bounds.html#ae2bddb983e507840449695dc2757cd2f", null ],
    [ "Set", "classlib_c_z_i_1_1_c_dim_bounds.html#a7a872729a919b4573755032fbfdfc183", null ],
    [ "TryGetInterval", "classlib_c_z_i_1_1_c_dim_bounds.html#abf42285e28ddc4843556f88b2292c494", null ]
];